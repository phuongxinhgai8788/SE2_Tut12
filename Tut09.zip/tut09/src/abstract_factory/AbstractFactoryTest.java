package abstract_factory;

/* Create the AbstractFactoryTest class which uses the FactoryProducer 
 * to get AbstractFactory in order to get factories 
 * of concrete classes by passing an information such as type.
 */

public class AbstractFactoryTest {
	//TO-DO: Implement the main() method for testing purpose
	public static void main(String[] args) {
		// get shape factory
		String shapeString1 = "rectANGle";
		String shapeString2 = "squAre";
		String shapeString3 = "Roundedrectangle";
		
		// get shape factory
		Boolean checkRounded1 = false;
		if(shapeString1.toUpperCase().contains("ROUNDED")) {
			checkRounded1=true;
		}
		FactoryProducer producer1 = new FactoryProducer();
		AbstractFactory factory1 = producer1.getFactory(checkRounded1);
		
		// get an object of Shape Rectangle
		Rectangle shapeObj1 = (Rectangle) factory1.getShape(shapeString1);
		
		// call draw method of Shape Rectangle
		shapeObj1.draw();
		
		//get shape factory
		Boolean checkRounded2 = false;
		if(shapeString2.toUpperCase().contains("ROUNDED")) {
			checkRounded2=true;
		}
		FactoryProducer producer2 = new FactoryProducer();
		AbstractFactory factory2 = producer2.getFactory(checkRounded2);
		
		// get an object of Shape Square
		Square shapeObj2 = (Square) factory2.getShape(shapeString2);
 
		// call draw method of Shape Square
		shapeObj2.draw();
 
		// get shape factory
		Boolean checkRounded3 = false;
		if(shapeString3.toUpperCase().contains("ROUNDED")) {
			checkRounded3=true;
		}
		FactoryProducer producer3 = new FactoryProducer();
		AbstractFactory factory3 = producer3.getFactory(checkRounded3);
 
		// get an object of Shape RoundedRectangle
		RoundedRectangle shapeObj3 = (RoundedRectangle) factory3.getShape(shapeString3);
		 
		// call draw method of Shape RoundedRectangle
		shapeObj3.draw();

 

	}
}