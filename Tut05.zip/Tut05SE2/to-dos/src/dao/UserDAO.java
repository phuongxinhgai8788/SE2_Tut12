package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import connect.DBConnect;
import model.User;

/**
 * This is a DAO (DATA ACCESS OBJECT) class which provides CRUD (CREATE - READ -
 * UPDATE - DELETE) database operations for the table user in the database
 */
public class UserDAO {
	PreparedStatement ps;
	String query;
	
	// Step 1: Establishing a Connection
	private Connection connection;

	
	public UserDAO() {
		
		this.connection=DBConnect.getConnection();
	}
	

	public List<User> selectAllUsers() {
		List<User> users = new ArrayList<>();
		try {
			// Step 2:Create a statement using connection object
			query = "SELECT * FROM user";
			ps = connection.prepareStatement(query);
			// Step 3: Execute the query or update query
			ResultSet rs = ps.executeQuery();
			// Step 4: Process the ResultSet object
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String address = rs.getString("address");
				String mobile = rs.getString("mobile");
				users.add(new User(id, name, address, mobile));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}
	
	public User selectUser(int id) {
		User user = null;
		try {
			// Create a statement using connection object
			query = "SELECT*FROM USER WHERE ID=?";
		    ps=connection.prepareStatement(query);
		    ps.setInt(1,id);
			// Execute the query
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
			String name=rs.getString("name");
			String address = rs.getString("address");
			String mobile = rs.getString("mobile");
			user = new User(name, address, mobile);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return user;
	}

	// TO-DO: Implement insertUser() method to add new record to table User  
	public int insertUser(User user) throws SQLException {
		int rowInserted=0;
		String name=user.getName();
		String address = user.getAddress();
		String mobile = user.getMobile();
		query = "INSERT INTO USER(Name, Address, Mobile) VALUES(?,?,?)";
		
		ps=connection.prepareStatement(query);
		ps.setString(1,name);
		ps.setString(2,address);
		ps.setString(3,mobile);
		rowInserted=ps.executeUpdate();
		return rowInserted;

	}

	// TO-DO: Implement updateUser() method to update record in table User  
	public int updateUser(User user) throws SQLException {
		int rowUpdated=0;
	    /*query="SELECT*FROM USER";
		PreparedStatement ps=connection.prepareStatement(query);
		ResultSet rs=ps.executeQuery(query);
		//The no.of row
		int rowNo=user.getId();
		String name=user.getName();
		String address = user.getAddress();
		String phone = user.getMobile();
		rs.absolute(rowNo);
		rs.updateString("Name",name);
		rs.updateString("Address", address);
		rs.updateString("Mobile", phone);
		rs.updateRow();*/
		query="UPDATE USER SET NAME=?, ADDRESS=?, MOBILE=? WHERE ID=?";
		ps=connection.prepareStatement(query);
		ps.setString(1, user.getName());
		ps.setString(2, user.getAddress());
		ps.setString(3, user.getMobile());
		ps.setInt(4, user.getId());
		rowUpdated=ps.executeUpdate();
		return rowUpdated;
	}

	// TO-DO: Implement deleteUser() method to delete record in table User  
	public boolean deleteUser(int id) throws SQLException {
		boolean rowDeleted = false;
		query ="DELETE FROM USER WHERE ID=?";
	    ps=connection.prepareStatement(query);
		ps.setInt(1,id);
		rowDeleted = ps.execute();

		return rowDeleted;
	}
}
