package source;

public class TestBag {
	public static void main(String[] args) {
	    BagInterface<String> bag1 = new ArrayBag();
		BagInterface<String> bag2 = new ArrayBag(100);
		
		System.out.println(" Before adding, this bag is empty or not? "+ bag1.isEmpty());
		 bag1.add("A");
		 bag1.add("B");
		 bag1.add("C");
		 bag1.add("D");
		 bag1.add("B");
		 bag1.add("C");
		 bag1.add("C");
		 System.out.println(" After adding, this bag is empty or not? "+ bag1.isEmpty());
		 System.out.println("All elements of this bag:");
		 bag1.toArray();
		 System.out.println("This bag has "+bag1.getFrequencyOf("C")+" C");
		 System.out.println("This bag contains E? "+bag1.contains("E"));
		 System.out.println("Is one C is removed? "+bag1.remove("C"));
		 System.out.println("After removing one C, this bag has: "+bag1.getFrequencyOf("C")+" C");
	}
	
	

}
