package source;

import java.lang.reflect.Array;
import java.util.Arrays;

public final class ArrayBag<T> implements BagInterface<T>{
	
	    //STEP 1: DETERMINES THE DATA FIELDS   
	    /**
	     * TO-DO: Declares the necessary attributes 
	     * bag: T[] 
	     * numberOfEntries: int
	     * DEFAULT_CAPACITY: int (30) 
	     * MAX_CAPACITY: int (3000)
	     */
		private final T[] bag;
		private int numberOfEntries;
		private static final int DEFAULT_CAPACITY = 30;
		private static final int MAX_CAPACITY = 3000;
	    //STEP 2: IMPLEMENTS THE CONSTRUCTORS
	    /**
	     * TO-DO: Creates an empty bag with default capacity
	     */
	    public ArrayBag() {
			bag = (T[]) new Object[DEFAULT_CAPACITY];
			numberOfEntries = bag.length;
	    }
	    
	    /**
	     * TO-DO: Creates an empty bag having a given capacity.
	     *
	     * @param desiredCapacity The integer capacity desired.
	     */
	    public ArrayBag(int desiredCapacity) {
			if(desiredCapacity<=MAX_CAPACITY) {
				bag = (T[]) new Object[desiredCapacity];
				numberOfEntries = bag.length;
	    	}else {
	    		throw new IllegalStateException("CAPACITY MUST SMALLER THAN "+MAX_CAPACITY);
	    	}
	    }
	    

	    //STEP 3: IMPLEMENTS THE FUNCTIONS
	    /**
	     * TO-DO: Adds a new entry to this bag.
	     *
	     * @param newEntry The object to be added as a new entry.
	     * @return True if the addition is successful, or false if not.
	     */
	    public boolean add(T newEntry) {
	    	for(int i=0;i<bag.length;i++) {
	    		if(bag[i]==null) {
	    			bag[i]=newEntry;
	    			return true;
	    		}
	    	}
	    		return false;
	    }

	    /**
	     * TO-DO: Retrieves all entries that are in this bag.
	     *
	     * @return A newly allocated array of all the entries in this bag.
	     */
	    public T[] toArray() {
	    	T[] bag2 = (T[]) new Object[bag.length];
	    	for(int i=0;i<bag.length;i++) {
	    	   bag2[i]=bag[i];
	    	   System.out.println(bag[i]+" ");
	    	}
	    	
	    	return bag2;
	    	
	    }

	    /**
	     * TO-DO: Sees whether this bag is empty.
	     *
	     * @return True if this bag is empty, or false if not.
	     */
	    public boolean isEmpty() {
	        return getCurrentSize()==0;
	    }

	    /**
	     * TO-DO: Gets the current number of entries in this bag.
	     *
	     * @return The integer number of entries currently in this bag.
	     */
	    public int getCurrentSize() {
	    	int count=0;
	    	for(int i=0;i<bag.length;i++) {
	    		if(bag[i]!=null) {
	    			count++;
	    		}
	    	}
	        return count;
	    }

	    /**
	     * TO-DO: Counts the number of times a given entry appears in this bag.
	     *
	     * @param anEntry The entry to be counted.
	     * @return The number of times anEntry appears in this bag.
	     */
	    public int getFrequencyOf(T anEntry) {
	    	int count=0;
	    	for(int i=0;i<bag.length;i++) {
	    		if(bag[i]==anEntry){
	    			count++;
	    		}
	    	}
	        return count;

	    }

	    /**
	     * TO-DO: Tests whether this bag contains a given entry.
	     *
	     * @param anEntry The entry to locate.
	     * @return True if this bag contains anEntry, or false otherwise.
	     */
	    public boolean contains(T anEntry) {
	        boolean check=false;
	    		if(getIndexOf(anEntry)!=-1) {
	    			check=true;
	    		}
	        return check;
	    }

	    /**
	     * TO-DO: Removes all entries from this bag.
	     */
	    public void clear() {
	    	for(int i=0;i<bag.length;i++) {
	    		bag[i]=null;                      
	    	}
	    }

	    /**
	     * TO-DO: Removes one unspecified entry from this bag, if possible.
	     *
	     * @return Either the removed entry, if the removal was successful, or null.
	     */
	    public T remove() {
	    	int length = bag.length;
	    	int randomPosition =  length*((int)Math.random());
	    	return removeEntry(randomPosition);

	    }

	    /**
	     * TO-DO: Removes one occurrence of a given entry from this bag.
	     *
	     * @param anEntry The entry to be removed.
	     * @return True if the removal was successful, or false if not.
	     */
	    public boolean remove(T anEntry) {
	    	boolean check=false;
	    	if(contains(anEntry)) {
	    		int pos=getIndexOf(anEntry);
	    		bag[pos]=null;
	    		check=true;
	    	}
	    	return check;
	    }

	    // TO-DO: Returns true if the array bag is full, or false if not.
	    private boolean isArrayFull() {
	        boolean check=true;
	        for(T entry: bag) {
	        	if(entry==null) {
	        		check=false;
	        		break;
	        	}
	        }
	        return check;

	    }

	    // TO-DO: Locates a given entry within the array bag.
	    // Returns the index of the entry, if located,
	    // or -1 otherwise.
	    // Precondition: checkInitialization has been called.
	    private int getIndexOf(T anEntry) {
	    	int pos=-1;
	        for(int i=0;i<bag.length;i++) {
	        	if(bag[i]==anEntry) {
	        		pos=i;
	        		break;
	        		}       	
	        }
	        return pos;

	    }

	    // TO-DO: Removes and returns the entry at a given index within the array.
	    // If no such entry exists, returns null.
	    // Precondition: 0 <= givenIndex < numberOfEntries.
	    // Precondition: checkInitialization has been called.
	    private T removeEntry(int givenIndex) {
	    	T entry=null;
	    	if(givenIndex<bag.length && givenIndex>=0) {
	    		entry=bag[givenIndex];
	    	}
	        return entry;

	    }

	}



