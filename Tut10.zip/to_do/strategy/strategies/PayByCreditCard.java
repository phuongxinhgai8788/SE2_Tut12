package strategies;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Concrete strategy. Implements credit card payment method.
 */
public class PayByCreditCard implements PayStrategy {
    private final BufferedReader READER = new BufferedReader(new InputStreamReader(System.in));
    private CreditCard card;

    /**
     * Collect credit card data.
     */
    @Override
    public void collectPaymentDetails() {
    	//TO-DO: Add 'try-catch' block to catch the IO error
    	String cardNumber =null; 
    	String expDate = null;
    	String cvvCode = null;
    	//TO-DO: Ask for card number, expiration date, CVV code then save them to suitable variables
    	try {
        	System.out.println("Enter credit card number:");
		    cardNumber = READER.readLine();
        	System.out.println("Enter credit card expiration date:");
            expDate=READER.readLine();
        	System.out.println("Enter credit card CVV code:");
            cvvCode=READER.readLine();


    	} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    	//TO-DO: Create new CreditCard instance with given information
    	card = new CreditCard(cardNumber, expDate, cvvCode);

        //TO-DO: Validate credit card number...
    	
    }

    //TO-DO: Implement the pay() method
    /**
     * After card validation we can charge customer's credit card.
     */
    @Override
    public boolean pay(int paymentAmount) {
    	/*if 'cardIsPresent' => display a message 
    	to show that customer is paying with Credit Card with money amount
    	then reduce the card amount with that number
    	finally return true else return false */
    	if(cardIsPresent()) {
    		System.out.println("You are going to pay "+paymentAmount+" with Credit Card");
    		card.setAmount(card.getAmount()-paymentAmount);
    		return true;
    	}
        
        return false;
    }

    private boolean cardIsPresent() {
        return card != null;
    }
}
