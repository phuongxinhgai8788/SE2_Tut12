package demo;

import adapter2.SquarePegAdapter;
import round.RoundHole;
import round.RoundPeg;
import square.SquarePeg;

public class DemoAdapter {
	public static void main(String[] args) {
		//TO-DO: Create 2 instances of RoundHole and RoundPeg with same radius
		double radius=6;
		RoundHole roundHole = new RoundHole(radius);
		RoundPeg roundPeg = new RoundPeg(radius);
	 
		//TO-DO: If RoundHole instance can "fits" with RoundPeg instance => show a message
		if(roundHole.fits(roundPeg)) {
			System.out.println("RoundHole fits RoundPeg");
		}
	 
		//TO-DO: Create 2 instances of SquarePeg with 2 different widths
		double width1= 3;
		double width2=4;
		SquarePeg squarePeg1 = new SquarePeg(width1);
		SquarePeg squarePeg2 = new SquarePeg(width2);
 
		//Note: You can't make RoundHole instance "fit" with SquarePeg instance
		//Therefore, we need to use Adapter for solving the problem.
		
		//TO-DO: Create 2 corresponding instances of SquarePegAdapter  
		SquarePegAdapter adapter1 = new SquarePegAdapter(squarePeg1);
		SquarePegAdapter adapter2 = new SquarePegAdapter(squarePeg2);
		 
		//TO-DO: If the RoundHole instance can "fits" with "small" RoundPegAdapter instance 
		//show a suitable message
		if(roundHole.fits(adapter1)) {
			System.out.println("Round hole can fit two square pegs");
		}
		//TO-DO: If the RoundHole instance can not "fits" with "big" RoundPegAdapter instance
		if(!roundHole.fits(adapter2)) {
			System.out.println("Round hole can not fit two square pegs");
		}
		//show a suitable message
	}
}
