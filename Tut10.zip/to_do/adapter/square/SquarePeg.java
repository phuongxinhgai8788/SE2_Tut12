package square;

/**
 * SquarePegs are not compatible with RoundHoles (they were implemented by
 * previous development team). But we have to integrate them into our program.
 */
public class SquarePeg {
	//TO-DO: Declare an attribute: name = width, type = double
	private double width;
   
	//TO-DO: Declare the constructor with a parameter
    public SquarePeg(double width) {
		super();
		this.width = width;
	}
     
	//TO-DO: Implement getWidth() method
    public double getWidth() {
		return this.width;
    }

	//TO-DO: Implement getSquare() method
    public double getSquare() {
    	
        double result = Math.pow(this.width, 2);
        //TO-DO: result = width^2
         
        return result;
    }
}
