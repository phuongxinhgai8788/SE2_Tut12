package middleware;

/**
 * ConcreteHandler. Checks a user's role.
 */
public class RoleCheckMiddleware extends Middleware {
	//TO-DO: Implement the check() method
    public boolean check(String email, String password) {
    	if (email == "admin@example.com") {
    		System.out.println("Welcome admin");
    	}
        else if(email=="user@example.com"){
    		System.out.println("Welcome to Supply Chain Management");
        }
          return checkNext(email, password);
    }
}