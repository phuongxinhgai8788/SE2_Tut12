package middleware;

import server.Server;

/**
 * ConcreteHandler. Checks whether a user with the given credentials exists.
 */
public class UserExistsMiddleware extends Middleware {
	

    private Server server;

    //TO-DO: Implement the UserExistsMiddleWare() method
    public UserExistsMiddleware(Server server) {
    	this.server = server;
         
    }

    public boolean check(String email, String password) {
    	//TO-DO: Check for invalid email => show error message then return false
         if(!server.hasEmail(email)) {
        	 System.out.println("There is not "+email+" registerd!");
        	 return false;
         } else if(!server.isValidPassword(email, password)) {
        	 System.out.println("Invalid password for email "+email);
        	 return false;
         }
         
        	 return checkNext(email, password);
         
    }
}