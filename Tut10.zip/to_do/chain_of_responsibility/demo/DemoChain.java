package demo;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import middleware.Middleware;
import middleware.RoleCheckMiddleware;
import middleware.ThrottlingMiddleware;
import middleware.UserExistsMiddleware;
import server.Server;

/**
 * Demo class. Everything comes together here.
 */
public class DemoChain {
    private static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private static Server server;

    private static void init() {
        server = new Server();
        //TO-DO: Register email & pass for 2 account types: admin & user
        String adminEmail="admin@example.com";
        String userEmail="user@example.com";
        String adminPassword="admin1234";
        String userPassword="user5678";
        server.register(userEmail, userPassword);
        server.register(adminEmail, adminPassword);
         

        // All checks are linked. Client can build various chains using the same components.
        Middleware middleware = new ThrottlingMiddleware(2);
        middleware.linkWith(new UserExistsMiddleware(server))
                .linkWith(new RoleCheckMiddleware());

        // Server gets a chain from client code.
        server.setMiddleware(middleware);
    }

    public static void main(String[] args) throws IOException {
        init();

        boolean success;
        do {
        	//TO-DO: Ask for email & password then save to suitable variables
        	System.out.println("Enter email");
        	String email=reader.readLine();
        	
        	System.out.println("Enter password");
        	String pass=reader.readLine();
        	
        	success = server.logIn(email, pass);
            
        	//TO-DO: Try to login to server with given email & password
        	//then store the result to variable 'success'
        } while (!success);
    }
}
