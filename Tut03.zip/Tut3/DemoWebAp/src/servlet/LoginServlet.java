package servlet;

	import java.io.IOException;

	import javax.servlet.RequestDispatcher;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	/**
	 * @author Admin
	 *
	 */
		@WebServlet("/loginServlet")
		public class LoginServlet extends HttpServlet{
			/**
		 * 
		 */
		private static final long serialVersionUID = 4532373161142028853L;
		public LoginServlet() {
			super();
		}
		
		protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
			String feedback=" ";
			req.setAttribute("feedback", feedback);
			RequestDispatcher rd=req.getRequestDispatcher("Login.jsp");
			rd.forward(req, res);
		}

			protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException{
				//read from fields
				String uname = req.getParameter("uname");
				String psw = req.getParameter("psw");
				//do processing
				String feedback;
				if(!uname.equals("PhuongLe")||!psw.equals("1234abcd")) {
					feedback="<span style = 'color:red'>Invalid username/password<span>";
				}else {
					feedback="<span>Welcome!</span>";
				}
				//Setting the attribute of the req object 
				req.setAttribute("feedback", feedback);
				RequestDispatcher rd=req.getRequestDispatcher("Login.jsp");
				//The req will be forwarded to the resource specified
				rd.forward(req, res);
			}


}
