package servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.FamilyDAO;
import dao.FriendDAO;
import dao.SubjectDAO;

/**
 * Servlet implementation class FamilyServlet
 * This servlet acts as a page controller for the application, handling all requests from the users;
 */
@WebServlet("/")
public class PageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private FamilyDAO familyDAO;
    private FriendDAO friendDAO;
    private SubjectDAO subjectDAO;
    public void init() {
    	familyDAO = new FamilyDAO();
    	friendDAO = new FriendDAO();
    	subjectDAO = new SubjectDAO();
    	
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			list(request, response);
		/*} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 */} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		private void list(HttpServletRequest request, HttpServletResponse response)throws IOException, ServletException, SQLException{
			String family_table = familyDAO.selectAllMembers();
			String friend_table = friendDAO.selectAllMembers();
		    String subject_table = subjectDAO.selectAllMembers();
			request.setAttribute("family_table", family_table);
			request.setAttribute("friend_table", friend_table);
			request.setAttribute("subject_table", subject_table);
	        response.setContentType("text/html;charset=UTF-8");
	        request.setCharacterEncoding("UTF-8");
			RequestDispatcher dispatcher = request.getRequestDispatcher("page.jsp");
			dispatcher.forward(request, response);
		}
	}

	


