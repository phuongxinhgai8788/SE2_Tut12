package models;

public class Subject {
	private String id;
	private String name;
	private String lecturer;
	private String tutor;
	public Subject(String id, String ten, String daylec, String daytut) {
		this.id=id;
		this.name=ten;
		this.lecturer=daylec;
		this.tutor=daytut;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLecturer() {
		return lecturer;
	}
	public void setLecturer(String lecturer) {
		this.lecturer = lecturer;
	}
	public String getTutor() {
		return tutor;
	}
	public void setTutor(String tutor) {
		this.tutor = tutor;
	}
	@Override
	public String toString() {
		return "<tr>"
				+ "<td>" + this.id + "</td>"
				+ "<td>" + this.name + "</td>"
				+ "<td>" + this.lecturer + "</td>"
				+ "<td>" + this.tutor + "</td>"
			+ "</tr>";

	}


}
