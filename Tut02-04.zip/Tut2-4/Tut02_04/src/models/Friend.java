package models;

public class Friend {
	private String name;
	private String appearance;
	private String personality;
	private String dob;
	public Friend(String ten, String ngoaihinh, String tinhcach) {
		super();
		this.name=ten;
		this.appearance=ngoaihinh;
		this.personality=tinhcach;
	}
	public Friend(String ten, String ngoaihinh, String tinhcach, String dob) {
		super();
		this.name=ten;
		this.appearance=ngoaihinh;
		this.personality=tinhcach;
		this.dob=dob;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getAppearance() {
		return appearance;
	}
	public void setAppearance(String appearance) {
		this.appearance = appearance;
	}
	public String getPersonality() {
		return personality;
	}
	public void setPersonality(String personality) {
		this.personality = personality;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	@Override
	public String toString() {
		return  "<td>" + this.name + "</td>"
				+ "<td>" + this.appearance + "</td>"
				+ "<td>" + this.personality + "</td>"
				+ "<td>" + this.dob + "</td>";

	}


}
