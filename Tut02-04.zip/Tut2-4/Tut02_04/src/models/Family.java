package models;

public class Family {
private String name;
private String role;
private String appearance;
private String personality;
private String dob;
public Family(String ten, String role, String ngoaihinh, String tinhcach) {
	super();
	this.name=ten;
	this.role=role;
	this.appearance=ngoaihinh;
	this.personality=tinhcach;
}
public Family(String ten, String role, String ngoaihinh, String tinhcach, String dob) {
	super();
	this.name=ten;
	this.role=role;
	this.appearance=ngoaihinh;
	this.personality=tinhcach;
	this.dob=dob;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public String getAppearance() {
	return appearance;
}
public void setAppearance(String appearance) {
	this.appearance = appearance;
}
public String getPersonality() {
	return personality;
}
public void setPersonality(String personality) {
	this.personality = personality;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
@Override
public String toString() {
	return "<tr>"
			+ "<td>" + this.name + "</td>"
			+ "<td>" + this.role + "</td>"
			+ "<td>" + this.appearance + "</td>"
			+ "<td>" + this.personality + "</td>"
			+ "<td>" + this.dob + "</td>"
		+ "</tr>";

}

}
