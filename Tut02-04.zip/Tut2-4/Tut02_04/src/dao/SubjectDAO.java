package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Subject;
/**
 * This is a DAO (DATA ACCESS OBJECT) class which provides 
 * CRUD (CREATE - READ - UPDATE - DELETE) database operations 
 * for the table subjects in the database
 */

public class SubjectDAO {
	public SubjectDAO() {
		
	}
	public String selectAllMembers(){
		List<Subject> subjects = new ArrayList<>();
		String subjects2="";
		//Step 1: Establishing a Connection
		Connection connection = DBConnect.getConnection();
		try {
			//Step 2: Create a statement using connection object
			String SELECT_ALL_MEMBERS ="SELECT*FROM subjects";
			PreparedStatement pr= connection.prepareStatement(SELECT_ALL_MEMBERS);
			//Step 3: Execute the query
			ResultSet rs = pr.executeQuery();
			//Step 4: Process the ResultSet object
			while(rs.next()) {
				String id=rs.getString("Id");
				String ten=rs.getString("Name");
				String daylec=rs.getString("Lecturer");
				String daytut=rs.getString("Tutor");
				subjects.add(new Subject(id, ten, daylec, daytut));
					
			}
			for(Subject subject:subjects) {
				subjects2=subjects2+subject.toString();
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return subjects2;
	}

}

