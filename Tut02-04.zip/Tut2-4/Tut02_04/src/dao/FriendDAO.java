
package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Friend;
/**
 * This is a DAO (DATA ACCESS OBJECT) class which provides 
 * CRUD (CREATE - READ - UPDATE - DELETE) database operations 
 * for the table friends in the database
 */

public class FriendDAO {
	public FriendDAO() {
		
	}
	public String selectAllMembers(){
		List<Friend> friends = new ArrayList<>();
		String friends2="";
		//Step 1: Establishing a Connection
		Connection connection = DBConnect.getConnection();
		try {
			//Step 2: Create a statement using connection object
			String SELECT_ALL_FRIENDS ="SELECT*FROM friends";
			PreparedStatement pr= connection.prepareStatement(SELECT_ALL_FRIENDS);
			//Step 3: Execute the query
			ResultSet rs = pr.executeQuery();
			//Step 4: Process the ResultSet object
			while(rs.next()) {
				String name=rs.getString("Name");
				//String role=rs.getString("Role");
				String appearance=rs.getString("Appearance");
				String personality=rs.getString("Personality");
				String dob=rs.getString("DOB");
				friends.add(new Friend(name, appearance, personality, dob));
					
			}
			int stt=1;
			for(Friend friend:friends ) {
				friends2=friends2+"<tr><td>"+stt+"</td>"+friend.toString()+"</tr>";
				stt++;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return friends2;
	}

}
