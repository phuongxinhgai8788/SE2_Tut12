package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import models.Family;
/**
 * This is a DAO (DATA ACCESS OBJECT) class which provides 
 * CRUD (CREATE - READ - UPDATE - DELETE) database operations 
 * for the table family in the database
 */

public class FamilyDAO {
	public FamilyDAO() {
		
	}
	public String selectAllMembers(){
		List<Family> members = new ArrayList<>();
		String members2 = "";
		//Step 1: Establishing a Connection
		Connection connection = DBConnect.getConnection();
		try {
			//Step 2: Create a statement using connection object
			String SELECT_ALL_MEMBERS ="SELECT*FROM family";
			PreparedStatement pr= connection.prepareStatement(SELECT_ALL_MEMBERS);
			//Step 3: Execute the query
			ResultSet rs = pr.executeQuery();
			//Step 4: Process the ResultSet object
			while(rs.next()) {
				String name=rs.getString("Name");
				String role=rs.getString("Role");
				String appearance=rs.getString("Appearance");
				String personality=rs.getString("Personality");
				String dob=rs.getString("DOB");
				members.add(new Family(name, role, appearance, personality, dob));
					
			}
			for(Family member:members) {
				members2=members2+member.toString();
			}
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return members2;
	}
	
}
