package book_shop;

public class Book {

	private String title;
	private String author;
	private double price;
	public Book(String title, String author, double price) {
		super();
		setTitle(title);
		setAuthor(author);
		setPrice(price);
	}
	public String getTitle() {
		return title;
	}
	protected void setTitle(String title) {
		if(validateTitle(title)) {
			this.title = title;
		}
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		if(validateAuthor(author)) {
			this.author = author;
		}
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		if(validatePrice(price)) {
			this.price = price;

		}
	}
	
	private boolean validateTitle(String title) {
		if(title.length()>=3) {
			return true;
		}
		throw new IllegalArgumentException("Title is not valid");
	}
	private boolean validateAuthor (String author) throws IllegalArgumentException {
		String[] author1=author.split(" ");
		for(String author2:author1) {
			String author3= author2.substring(0, 1);
			if(author3.matches(".*[0-9].*")) {
				throw new IllegalArgumentException("Author is not valid");
			}
	}
		return true;
	}
	private boolean validatePrice(double price) {
		if(price<=0) {
			throw new IllegalArgumentException("Price is not valid");
		}
		return true;
	}
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("Type: ").append(this.getClass().getSimpleName())
		.append(System.lineSeparator())
		.append("Title: ").append(this.getTitle())
		.append(System.lineSeparator())
		.append("Author: ").append(this.getAuthor())
		.append(System.lineSeparator())
		.append("Price: ").append(this.getPrice())
		.append(System.lineSeparator());
		return sb.toString();
	
}
}
