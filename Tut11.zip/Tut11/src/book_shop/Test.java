package book_shop;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter title:");
		String title = sc.nextLine();
		System.out.println("Please enter author:");
		String author = sc.nextLine();
		System.out.println("Please enter price:");
		double price = sc.nextDouble();
		GoldenEditionBook gold = new GoldenEditionBook(title, author, price);
		System.out.println(gold.toString());
		sc.close();
		
	}
}
