import java.util.Scanner;

import man_kind.Student;
import man_kind.Worker;

public class Test {
public static void main(String[] args) {
	Scanner sc = new Scanner (System.in);
	System.out.println("Please enter worker's first name:");
	String firstName = sc.nextLine();
	System.out.println("Please enter worker's last name:");
	String lastName = sc.nextLine();
	System.out.println("Please enter worker's week salary:");
	double weekSalary = sc.nextDouble();
	System.out.println("Please enter worker's hour per day:");
	int hour_per_day = sc.nextInt();
	Worker worker = new Worker(firstName, lastName, weekSalary, hour_per_day);
	System.out.println(worker.toString());
	
	System.out.println("Please enter student's first name:");
	String firstName2 = sc.nextLine();
	System.out.println("Please enter student's last name:");
	String lastName2 = sc.nextLine();
	System.out.println("Please enter student's faculty number:");
	String number = sc.nextLine();
	Student student = new Student(firstName2, lastName2, number);
	System.out.println(student.toString());
	sc.close();

}
}
