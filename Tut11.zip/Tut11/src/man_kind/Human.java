package man_kind;

public class Human {
	protected String firstName;
	protected String lastName;
	public Human(String firstName, String lastName) {
		super();
		setFirstName(firstName);
		setLastName(lastName);
	}
	public String getFirstName() {
		return firstName;
	}
	protected void setFirstName(String firstName) {
		if(validateFirstName(firstName)) {
			this.firstName = firstName;
		}
	}
	public String getLastName() {
		return lastName;
	}
	protected void setLastName(String lastName) {
		if(validateLastName(lastName)) {
			this.lastName = lastName;
		}
	}
	private boolean  validateFirstName(String firstName) {
		String firstLetter = firstName.substring(0, 1);
		if(!firstLetter.matches(".*[A-Z].*")) {
			throw new IllegalArgumentException("Expected upper case letter!Argument: firstName");
		}else if(firstName.length()<=4) {
			throw new IllegalArgumentException("Expected length at least 4 symbols!Argument: firstName");
		}else {
			return true;
		}
	}
	private boolean validateLastName(String lastName) {
		String firstLetter = lastName.substring(0, 1);
		if(!firstLetter.matches(".*[A-Z]*.")) {
			throw new IllegalArgumentException("Expected upper case letter!Argument: lastName");
		}else if(lastName.length()<=3) {
			throw new IllegalArgumentException("Expected length at least 3 symbols!Argument: lastName");
		}else {
			return true;
		}
	}
	
}
