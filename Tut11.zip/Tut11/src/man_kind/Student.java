package man_kind;

public class Student extends Human{
	private String facultyNumber;

	public Student(String firstName, String lastName, String facultyNumber) {
		super(firstName, lastName);
		setFacultyNumber(facultyNumber);
	}
	private boolean validateFacultyNumber(String number) {
		if(number.length()<5 || number.length()>10 ||number.matches(".*[^0-9].*") ) {
			throw new IllegalArgumentException("Invalid faculty number!");
		}
		return true;
	}
	
	protected void setFacultyNumber(String number) {
		if(validateFacultyNumber(number)) {
			this.facultyNumber=number;
		}
	}
	@Override
	public String toString() {
		return "First Name: "+firstName+"\n Last Name: "+lastName+"\n Faculty number:"+facultyNumber;
	}
	
}
