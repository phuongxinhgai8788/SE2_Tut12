package man_kind;

public class Worker extends Human{
	private double weekSalary;
	private int hourPerDay;
	public Worker(String firstName, String lastName, double weekSalary, int hourPerDay) {
		super(firstName, lastName);
		this.weekSalary = weekSalary;
		this.hourPerDay = hourPerDay;
	}
	
	@Override
	protected void setLastName(String lastName) {
		if(!(lastName.length()>3)) {
			throw new IllegalArgumentException("Expected length more than 3 symbols!Argument: lastName");
		}
		super.lastName = lastName;
	}
	public double getWeekSalary() {
		return weekSalary;
	}
	protected void setWeekSalary(double weekSalary) {
		if(validateWeekSalary(weekSalary)) {
			this.weekSalary = weekSalary;
		}
		
	}
	public int getHourPerDay() {
		return hourPerDay;
	}
	public void setHourPerDay(int hourPerDay) {
		if(validateWorkingHours(hourPerDay)) {
			this.hourPerDay = hourPerDay;
		}
	}
	private boolean validateWeekSalary(double weekSalary) {
		if(weekSalary<=10) {
			throw new IllegalArgumentException("\"Expected value mismatch!Argument:\r\n"
					+ "\r\n"
					+ "weekSalary\"");
		}
		return true;
	}
	private boolean validateWorkingHours(double workingHour) {
		if(workingHour<1 || workingHour>12) {
			throw new IllegalArgumentException("Expected value mismatch!Argument: workHoursPerDay");
		}
		return true;
	}
	public double getSalaryPerHour() {
		double result = weekSalary/hourPerDay;
		int result1 = (int) (result*100);
		double result2 = result1;
		double result3 = result2/100;
		return result3;
	}
	@Override
	public String toString() {
		return "First Name: "+firstName+"\n Last Name: "+lastName+"\n Week Salary: "+weekSalary+"\n Hours per day: "+hourPerDay+"\n Salary per hour:  "+getSalaryPerHour();
	}
}
