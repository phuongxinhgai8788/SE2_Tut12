package person_and_child;

import java.util.Scanner;

public class Test {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter name of a child: ");
		String name = sc.nextLine();
		System.out.println("Please enter age of a child: ");
		int age = sc.nextInt();
		System.out.println("Please enter address of a child: ");
		String address = sc.nextLine();
		Child child = new Child(name, age, address);
		System.out.println(child.toString());	
		sc.close();
	}

}
