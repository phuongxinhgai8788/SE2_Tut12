package person_and_child;

public class Person {
	
	private String name;
	private int age;
	private String address;
	public Person(String name, int age, String address) {
		super();
		setName(name);
		setAge(age);
		setAddress(address);

		
	}
	public String getName() {
		return name;
	}
	protected void setName (String name)throws IllegalArgumentException {
		if(name.length()<3) {
			throw new IllegalArgumentException("Name's length should not be less than 3 symbols!");
		}else {
			this.name = name;
		}

	}
	public int getAge() {
		return age;
	}
	protected void setAge(int age) {
		if(age<0) {
			throw new IllegalArgumentException("Age must be positive!");
		}else {
			this.age = age;

	}

	}
	public String getAddress() {
		return address;
	}
	protected void setAddress(String address) {
			this.address = address;
	}
	
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(String.format("Name: %s, Age: %d, Address: %s", this.name, this.age, this.address));
		return sb.toString();
	}
	
}
