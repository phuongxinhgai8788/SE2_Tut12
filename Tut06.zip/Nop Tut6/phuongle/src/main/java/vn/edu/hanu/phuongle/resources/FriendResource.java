package vn.edu.hanu.phuongle.resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import vn.edu.hanu.phuongle.model.Friend;
import vn.edu.hanu.phuongle.service.FriendService;

@Path("friend")

public class FriendResource {
	
	FriendService friendService = new FriendService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Friend> getFriend(){
		return friendService.getAllFriends();
	}

}
