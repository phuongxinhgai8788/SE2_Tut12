package vn.edu.hanu.phuongle.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)


public class Roomate {
	private String name;
	private String appearance;
	private String personality;
	
	
	public Roomate(String name, String appearance, String personality) {
		super();
		this.name = name;
		this.appearance = appearance;
		this.personality = personality;
	}


	public Roomate() {
		super();
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAppearance() {
		return appearance;
	}


	public void setAppearance(String appearance) {
		this.appearance = appearance;
	}


	public String getPersonality() {
		return personality;
	}


	public void setPersonality(String personality) {
		this.personality = personality;
	}
	
	

}
