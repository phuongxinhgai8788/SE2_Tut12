package vn.edu.hanu.phuongle.service;

import java.util.ArrayList;
import java.util.List;

import vn.edu.hanu.phuongle.model.Roomate;

public class RoomateService {
	public List<Roomate> getAllRoomates(){
		Roomate r1 = new Roomate("Bùi Thảo","Tóc dày, dáng xinh, eo thon", "Nhanh nhẹn, tháo vát, thích ngủ, quyết đoán");
		Roomate r2 = new Roomate("Phan Nga", "Nhỏ nhắn, đẹp gái, thích làm con trai", "Làm cái gì cũng nhanh trừ ăn cơm");
		Roomate r3 = new Roomate("Ngọc Mai","Cao, to, eo nhỏ, chân to","Gặp không ai bảo năm nhất, con nhà Richkid nhưng tính con nhà lính");
		Roomate r4 = new Roomate("Tô Hồng", "Trắng, mắt to, thích phong cách công túa","Nhanh nhẹn, con chiên của Chúa, thích phong cách công túa");
		
		List<Roomate> list = new ArrayList<>();
		list.add(r4);
		list.add(r3);
		list.add(r2);
		list.add(r1);
		return list;
	}

}

