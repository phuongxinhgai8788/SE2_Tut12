package vn.edu.hanu.phuongle.resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import vn.edu.hanu.phuongle.model.Roomate;
import vn.edu.hanu.phuongle.service.RoomateService;

@Path("roomate")

public class RoomateResource {
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Roomate> getRoomate(){
		RoomateService roomateService = new RoomateService();
		return roomateService.getAllRoomates();
	}

}
