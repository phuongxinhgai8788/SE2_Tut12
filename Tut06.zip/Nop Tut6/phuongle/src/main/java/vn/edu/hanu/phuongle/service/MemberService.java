package vn.edu.hanu.phuongle.service;

import java.util.ArrayList;
import java.util.List;

import vn.edu.hanu.phuongle.model.Member;


public class MemberService {
	
public List<Member> getAllMembers(){
		
		Member m1 = new Member("Đượm Đà", "Má ngựa","Hoa khôi ao làng","Yêu là mắng");
		Member m2 = new Member("Đính Xuân","Bố hổ", "Đã từng rất còi", "Yêu chị gái nhất trên đời");
		Member m3 = new Member("Ngọc Thị", "Bác na","Bé nhưng t khôn", "Em trai là để mắng, Chùa là nhà thứ hai, Hàng xóm là hội ce");
		Member m4 = new Member("Không ai đc biết tên t","Ông mùi","Ba toong là bạn, khăn mặt là vợ", "T thích mì tôm, t thích cho cháu gái ăn mì tôm sống");
		 List<Member> list = new ArrayList<>();
		 list.add(m4);
		 list.add(m3);
		 list.add(m2);
		 list.add(m1);
		 return list;
	}
}
