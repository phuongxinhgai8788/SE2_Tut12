package vn.edu.hanu.phuongle.service;

import java.util.ArrayList;
import java.util.List;

import vn.edu.hanu.phuongle.model.Friend;

public class FriendService {
	
	public List<Friend> getAllFriends(){
		Friend f1= new Friend("Ánh Đỡ", "Chuẩn bị gầy", "Hay dỗi");
		Friend f2 = new Friend("Ánh Điên", "Gầy, trắng và xinh gái", "Quan tâm tới bạn bè");
		Friend f3 = new Friend("Mừng Chế", "Đã tăng cân chóng mặt", "Dễ gần, thích tám chuyện");
		Friend f4 = new Friend("Lam Núi", "Mắt nâu, da vàng đúng chuẩn châu Á", "Hài hước, dễ chịu và sành ăn");
		Friend f5 = new Friend("Thảo Chuẩn", "Xinh gái từ nhỏ, còi bẩm sinh","Hài hước, thẳng thắn và hơi bựa");
		List<Friend> list = new ArrayList<>();
		list.add(f5);
		list.add(f4);
		list.add(f3);
		list.add(f2);
		list.add(f1);
		return list;
	}

}
