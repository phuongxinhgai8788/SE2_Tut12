package vn.edu.hanu.phuongle.resources;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import javax.ws.rs.core.MediaType;

import vn.edu.hanu.phuongle.model.Member;
import vn.edu.hanu.phuongle.service.MemberService;

@Path("member")
public class MemberResource {
	MemberService memberService = new MemberService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Member> getMember(){
		return memberService.getAllMembers();


}
}
